import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import HeroSection from './components/HeroSection';
import ToolsGrid from './components/ToolsGrid';
import FeaturesSection from './components/FeaturesSection';
import AppsSection from './components/AppsSection';
import MergePDF from './pages/MergePDF';

function HomePage() {
  return (
    <>
      <HeroSection />
      <ToolsGrid />
      <FeaturesSection />
      <AppsSection />
    </>
  );
}

function App() {
  return (
    <Router>
      <div className="min-h-screen flex flex-col">
        <Navbar />

        <main className="flex-grow">
          <Routes>
            <Route path="/" element={<HomePage />} />
            <Route path="/merge-pdf" element={<MergePDF />} />
            {/* Add more routes for other tools */}
          </Routes>
        </main>

        <Footer />
      </div>
    </Router>
  );
}

export default App;
