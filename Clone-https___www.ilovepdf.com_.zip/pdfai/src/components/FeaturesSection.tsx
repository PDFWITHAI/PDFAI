const FeaturesSection = () => {
  return (
    <>
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl font-bold text-pdf-gray mb-12">The PDF software trusted by millions of users</h2>
          <p className="text-lg text-pdf-gray mb-10 max-w-3xl mx-auto">
            PDFAI is your number one web app for editing PDF with ease. Enjoy all the tools you need to work
            efficiently with your digital documents while keeping your data safe and secure.
          </p>

          <div className="flex flex-wrap justify-center gap-12">
            <div className="flex flex-col items-center">
              <div className="mb-4">
                <svg width="50" height="50" viewBox="0 0 50 50" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M25 4.16663C13.5 4.16663 4.16669 13.5 4.16669 25C4.16669 36.5 13.5 45.8333 25 45.8333C36.5 45.8333 45.8334 36.5 45.8334 25C45.8334 13.5 36.5 4.16663 25 4.16663ZM20.8334 35.4166L10.4167 25L13.5417 21.875L20.8334 29.1666L36.4584 13.5416L39.5834 16.6666L20.8334 35.4166Z" fill="#444a53" opacity="0.7" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-pdf-gray mb-2">ISO 27001</h3>
            </div>

            <div className="flex flex-col items-center">
              <div className="mb-4">
                <svg width="50" height="50" viewBox="0 0 50 50" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M41.6667 16.6666H37.5V12.5C37.5 7.29163 33.2084 3.00006 28 3.00006C22.7917 3.00006 18.5 7.29163 18.5 12.5V16.6666H14.3334C12.6667 16.6666 11.3334 18 11.3334 19.6666V41.6666C11.3334 43.3333 12.6667 44.6666 14.3334 44.6666H41.6667C43.3334 44.6666 44.6667 43.3333 44.6667 41.6666V19.6666C44.6667 18 43.3334 16.6666 41.6667 16.6666ZM28 34.6666C26.3334 34.6666 25 33.3333 25 31.6666C25 30 26.3334 28.6666 28 28.6666C29.6667 28.6666 31 30 31 31.6666C31 33.3333 29.6667 34.6666 28 34.6666ZM33.5 16.6666H22.5V12.5C22.5 9.49996 24.9584 7.04163 28 7.04163C31.0417 7.04163 33.5 9.49996 33.5 12.5V16.6666Z" fill="#444a53" opacity="0.7" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-pdf-gray mb-2">Secure connection HTTPS</h3>
            </div>

            <div className="flex flex-col items-center">
              <div className="mb-4">
                <svg width="50" height="50" viewBox="0 0 50 50" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M29.1667 4.16663H12.5C10.25 4.16663 8.41669 6.04163 8.41669 8.33329L8.33335 41.6666C8.33335 43.9583 10.1667 45.8333 12.4167 45.8333H37.5C39.7917 45.8333 41.6667 43.9583 41.6667 41.6666V16.6666L29.1667 4.16663ZM33.3334 37.5H16.6667V33.3333H33.3334V37.5ZM33.3334 29.1666H16.6667V25H33.3334V29.1666ZM27.0834 18.75V7.29163L38.5417 18.75H27.0834Z" fill="#444a53" opacity="0.7" />
                </svg>
              </div>
              <h3 className="text-xl font-semibold text-pdf-gray mb-2">PDF Association</h3>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-gray-800 text-white">
        <div className="container mx-auto px-4">
          <div className="flex flex-col lg:flex-row items-center">
            <div className="lg:w-1/2 mb-8 lg:mb-0">
              <h2 className="text-3xl font-bold mb-6">Get more with Premium</h2>
              <p className="text-lg mb-8">
                Complete projects faster with batch file processing, convert scanned documents with OCR and e-sign your
                business agreements.
              </p>
              <a
                href="/premium"
                className="inline-block bg-yellow-500 hover:bg-yellow-600 text-gray-900 font-semibold px-6 py-3 rounded transition-colors"
              >
                Get Premium
              </a>
            </div>
            <div className="lg:w-1/2 flex justify-center lg:justify-end">
              <img
                src="https://ext.same-assets.com/2319839531/1614829733.svg"
                alt="Premium Features"
                className="max-w-full h-auto max-h-64"
              />
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default FeaturesSection;
