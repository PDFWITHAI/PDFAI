import { useState } from 'react';
import { Link } from 'react-router-dom';

const Navbar = () => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const toggleMenu = () => {
    setIsMenuOpen(!isMenuOpen);
  };

  return (
    <nav className="bg-white border-b border-gray-100 py-3 px-4 md:px-6">
      <div className="container mx-auto">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Link to="/" className="mr-8">
              <img src="/logo.svg" alt="PDFAI" width="114" height="40" />
            </Link>
            <div className="hidden md:flex space-x-4 text-sm font-medium">
              <Link to="/merge-pdf" className="text-pdf-gray hover:text-pdf-red">MERGE PDF</Link>
              <Link to="/split-pdf" className="text-pdf-gray hover:text-pdf-red">SPLIT PDF</Link>
              <Link to="/compress-pdf" className="text-pdf-gray hover:text-pdf-red">COMPRESS PDF</Link>
              <div className="group relative">
                <button className="flex items-center text-pdf-gray hover:text-pdf-red">
                  CONVERT PDF <svg className="ml-1 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
                </button>
                <div className="absolute left-0 mt-2 w-48 bg-white shadow-lg rounded-md overflow-hidden z-10 hidden group-hover:block">
                  <div className="py-2">
                    <div className="px-4 py-2 text-xs font-semibold text-pdf-lightgray">Convert to PDF</div>
                    <Link to="/jpg-to-pdf" className="block px-4 py-2 text-sm text-pdf-gray hover:bg-gray-100">JPG to PDF</Link>
                    <Link to="/word-to-pdf" className="block px-4 py-2 text-sm text-pdf-gray hover:bg-gray-100">WORD to PDF</Link>
                    <Link to="/powerpoint-to-pdf" className="block px-4 py-2 text-sm text-pdf-gray hover:bg-gray-100">POWERPOINT to PDF</Link>
                    <Link to="/excel-to-pdf" className="block px-4 py-2 text-sm text-pdf-gray hover:bg-gray-100">EXCEL to PDF</Link>
                    <Link to="/html-to-pdf" className="block px-4 py-2 text-sm text-pdf-gray hover:bg-gray-100">HTML to PDF</Link>
                    <div className="px-4 py-2 text-xs font-semibold text-pdf-lightgray">Convert from PDF</div>
                    <Link to="/pdf-to-jpg" className="block px-4 py-2 text-sm text-pdf-gray hover:bg-gray-100">PDF to JPG</Link>
                    <Link to="/pdf-to-word" className="block px-4 py-2 text-sm text-pdf-gray hover:bg-gray-100">PDF to WORD</Link>
                    <Link to="/pdf-to-powerpoint" className="block px-4 py-2 text-sm text-pdf-gray hover:bg-gray-100">PDF to POWERPOINT</Link>
                    <Link to="/pdf-to-excel" className="block px-4 py-2 text-sm text-pdf-gray hover:bg-gray-100">PDF to EXCEL</Link>
                    <Link to="/pdf-to-pdfa" className="block px-4 py-2 text-sm text-pdf-gray hover:bg-gray-100">PDF to PDF/A</Link>
                  </div>
                </div>
              </div>
              <div className="group relative">
                <button className="flex items-center text-pdf-gray hover:text-pdf-red">
                  ALL PDF TOOLS <svg className="ml-1 w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path></svg>
                </button>
                <div className="absolute left-0 mt-2 w-screen max-w-4xl bg-white shadow-lg rounded-md overflow-hidden z-10 hidden group-hover:block">
                  <div className="grid grid-cols-4 gap-4 p-6">
                    <div>
                      <div className="font-semibold text-pdf-lightgray text-xs mb-2">Organize PDF</div>
                      <ul className="space-y-2">
                        <li><Link to="/merge-pdf" className="text-sm text-pdf-gray hover:text-pdf-red">Merge PDF</Link></li>
                        <li><Link to="/split-pdf" className="text-sm text-pdf-gray hover:text-pdf-red">Split PDF</Link></li>
                        <li><Link to="/remove-pages" className="text-sm text-pdf-gray hover:text-pdf-red">Remove pages</Link></li>
                        <li><Link to="/extract-pages" className="text-sm text-pdf-gray hover:text-pdf-red">Extract pages</Link></li>
                        <li><Link to="/organize-pdf" className="text-sm text-pdf-gray hover:text-pdf-red">Organize PDF</Link></li>
                        <li><Link to="/scan-to-pdf" className="text-sm text-pdf-gray hover:text-pdf-red">Scan to PDF</Link></li>
                      </ul>
                    </div>
                    <div>
                      <div className="font-semibold text-pdf-lightgray text-xs mb-2">Optimize PDF</div>
                      <ul className="space-y-2">
                        <li><Link to="/compress-pdf" className="text-sm text-pdf-gray hover:text-pdf-red">Compress PDF</Link></li>
                        <li><Link to="/repair-pdf" className="text-sm text-pdf-gray hover:text-pdf-red">Repair PDF</Link></li>
                        <li><Link to="/ocr-pdf" className="text-sm text-pdf-gray hover:text-pdf-red">OCR PDF</Link></li>
                      </ul>
                      <div className="font-semibold text-pdf-lightgray text-xs mt-4 mb-2">PDF Security</div>
                      <ul className="space-y-2">
                        <li><Link to="/unlock-pdf" className="text-sm text-pdf-gray hover:text-pdf-red">Unlock PDF</Link></li>
                        <li><Link to="/protect-pdf" className="text-sm text-pdf-gray hover:text-pdf-red">Protect PDF</Link></li>
                        <li><Link to="/sign-pdf" className="text-sm text-pdf-gray hover:text-pdf-red">Sign PDF</Link></li>
                        <li><Link to="/redact-pdf" className="text-sm text-pdf-gray hover:text-pdf-red">Redact PDF</Link></li>
                      </ul>
                    </div>
                    <div>
                      <div className="font-semibold text-pdf-lightgray text-xs mb-2">Convert to PDF</div>
                      <ul className="space-y-2">
                        <li><Link to="/jpg-to-pdf" className="text-sm text-pdf-gray hover:text-pdf-red">JPG to PDF</Link></li>
                        <li><Link to="/word-to-pdf" className="text-sm text-pdf-gray hover:text-pdf-red">WORD to PDF</Link></li>
                        <li><Link to="/powerpoint-to-pdf" className="text-sm text-pdf-gray hover:text-pdf-red">POWERPOINT to PDF</Link></li>
                        <li><Link to="/excel-to-pdf" className="text-sm text-pdf-gray hover:text-pdf-red">EXCEL to PDF</Link></li>
                        <li><Link to="/html-to-pdf" className="text-sm text-pdf-gray hover:text-pdf-red">HTML to PDF</Link></li>
                      </ul>
                    </div>
                    <div>
                      <div className="font-semibold text-pdf-lightgray text-xs mb-2">Convert from PDF</div>
                      <ul className="space-y-2">
                        <li><Link to="/pdf-to-jpg" className="text-sm text-pdf-gray hover:text-pdf-red">PDF to JPG</Link></li>
                        <li><Link to="/pdf-to-word" className="text-sm text-pdf-gray hover:text-pdf-red">PDF to WORD</Link></li>
                        <li><Link to="/pdf-to-powerpoint" className="text-sm text-pdf-gray hover:text-pdf-red">PDF to POWERPOINT</Link></li>
                        <li><Link to="/pdf-to-excel" className="text-sm text-pdf-gray hover:text-pdf-red">PDF to EXCEL</Link></li>
                        <li><Link to="/pdf-to-pdfa" className="text-sm text-pdf-gray hover:text-pdf-red">PDF to PDF/A</Link></li>
                      </ul>
                      <div className="font-semibold text-pdf-lightgray text-xs mt-4 mb-2">Edit PDF</div>
                      <ul className="space-y-2">
                        <li><Link to="/rotate-pdf" className="text-sm text-pdf-gray hover:text-pdf-red">Rotate PDF</Link></li>
                        <li><Link to="/add-page-numbers" className="text-sm text-pdf-gray hover:text-pdf-red">Add page numbers</Link></li>
                        <li><Link to="/add-watermark" className="text-sm text-pdf-gray hover:text-pdf-red">Add watermark</Link></li>
                        <li><Link to="/edit-pdf" className="text-sm text-pdf-gray hover:text-pdf-red">Edit PDF</Link></li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-4">
            <div className="hidden md:flex">
              <Link to="/login" className="text-pdf-gray hover:text-pdf-red font-medium text-sm mr-3">Login</Link>
              <Link to="/signup" className="bg-pdf-red text-white px-3 py-1.5 rounded text-sm font-medium">Sign up</Link>
            </div>
            <button className="md:hidden" onClick={toggleMenu}>
              <svg className="w-6 h-6 text-pdf-gray" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 6h16M4 12h16M4 18h16"></path>
              </svg>
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isMenuOpen && (
        <div className="md:hidden mt-4 pt-4 border-t border-gray-200">
          <div className="px-2 space-y-2">
            <Link to="/merge-pdf" className="block px-3 py-2 text-pdf-gray font-medium rounded-md hover:bg-gray-100">MERGE PDF</Link>
            <Link to="/split-pdf" className="block px-3 py-2 text-pdf-gray font-medium rounded-md hover:bg-gray-100">SPLIT PDF</Link>
            <Link to="/compress-pdf" className="block px-3 py-2 text-pdf-gray font-medium rounded-md hover:bg-gray-100">COMPRESS PDF</Link>
            <details className="group">
              <summary className="flex justify-between px-3 py-2 text-pdf-gray font-medium rounded-md hover:bg-gray-100 cursor-pointer">
                CONVERT PDF
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path>
                </svg>
              </summary>
              <div className="px-3 py-2 space-y-2">
                <div className="font-semibold text-pdf-lightgray text-xs">Convert to PDF</div>
                <Link to="/jpg-to-pdf" className="block py-1 text-sm text-pdf-gray">JPG to PDF</Link>
                <Link to="/word-to-pdf" className="block py-1 text-sm text-pdf-gray">WORD to PDF</Link>
                <Link to="/powerpoint-to-pdf" className="block py-1 text-sm text-pdf-gray">POWERPOINT to PDF</Link>
                <Link to="/excel-to-pdf" className="block py-1 text-sm text-pdf-gray">EXCEL to PDF</Link>
                <Link to="/html-to-pdf" className="block py-1 text-sm text-pdf-gray">HTML to PDF</Link>
                <div className="font-semibold text-pdf-lightgray text-xs mt-3">Convert from PDF</div>
                <Link to="/pdf-to-jpg" className="block py-1 text-sm text-pdf-gray">PDF to JPG</Link>
                <Link to="/pdf-to-word" className="block py-1 text-sm text-pdf-gray">PDF to WORD</Link>
                <Link to="/pdf-to-powerpoint" className="block py-1 text-sm text-pdf-gray">PDF to POWERPOINT</Link>
                <Link to="/pdf-to-excel" className="block py-1 text-sm text-pdf-gray">PDF to EXCEL</Link>
                <Link to="/pdf-to-pdfa" className="block py-1 text-sm text-pdf-gray">PDF to PDF/A</Link>
              </div>
            </details>
            <details className="group">
              <summary className="flex justify-between px-3 py-2 text-pdf-gray font-medium rounded-md hover:bg-gray-100 cursor-pointer">
                ALL PDF TOOLS
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7"></path>
                </svg>
              </summary>
              <div className="px-3 py-2">
                <div className="font-semibold text-pdf-lightgray text-xs mb-2">Organize PDF</div>
                <ul className="space-y-1 mb-4">
                  <li><Link to="/merge-pdf" className="block text-sm text-pdf-gray">Merge PDF</Link></li>
                  <li><Link to="/split-pdf" className="block text-sm text-pdf-gray">Split PDF</Link></li>
                  <li><Link to="/remove-pages" className="block text-sm text-pdf-gray">Remove pages</Link></li>
                  <li><Link to="/extract-pages" className="block text-sm text-pdf-gray">Extract pages</Link></li>
                  <li><Link to="/organize-pdf" className="block text-sm text-pdf-gray">Organize PDF</Link></li>
                  <li><Link to="/scan-to-pdf" className="block text-sm text-pdf-gray">Scan to PDF</Link></li>
                </ul>
                <div className="font-semibold text-pdf-lightgray text-xs mb-2">Optimize PDF</div>
                <ul className="space-y-1 mb-4">
                  <li><Link to="/compress-pdf" className="block text-sm text-pdf-gray">Compress PDF</Link></li>
                  <li><Link to="/repair-pdf" className="block text-sm text-pdf-gray">Repair PDF</Link></li>
                  <li><Link to="/ocr-pdf" className="block text-sm text-pdf-gray">OCR PDF</Link></li>
                </ul>
                <div className="font-semibold text-pdf-lightgray text-xs mb-2">PDF Security</div>
                <ul className="space-y-1 mb-4">
                  <li><Link to="/unlock-pdf" className="block text-sm text-pdf-gray">Unlock PDF</Link></li>
                  <li><Link to="/protect-pdf" className="block text-sm text-pdf-gray">Protect PDF</Link></li>
                  <li><Link to="/sign-pdf" className="block text-sm text-pdf-gray">Sign PDF</Link></li>
                  <li><Link to="/redact-pdf" className="block text-sm text-pdf-gray">Redact PDF</Link></li>
                </ul>
              </div>
            </details>
            <div className="pt-4 mt-2 border-t border-gray-200 flex items-center space-x-4">
              <Link to="/login" className="px-3 py-2 text-pdf-gray font-medium">Login</Link>
              <Link to="/signup" className="bg-pdf-red text-white px-4 py-2 rounded text-sm font-medium">Sign up</Link>
            </div>
          </div>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
