const AppsSection = () => {
  return (
    <section className="py-16 bg-pdf-bg">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-pdf-gray text-center mb-12">Looking for another solution?</h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {/* Desktop App */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="p-6">
              <h3 className="text-2xl font-bold text-pdf-gray mb-4">PDFAI Desktop</h3>
              <p className="text-pdf-gray mb-6">
                Download the <a href="/desktop" className="text-pdf-red font-medium">PDFAI Desktop</a> App to
                work with your favorite PDF tools on your Mac or Windows PC. Get a
                lightweight PDF app that helps you process heavy PDF tasks offline in seconds.
              </p>
              <a
                href="/desktop"
                className="inline-block bg-pdf-red text-white font-medium px-4 py-2 rounded hover:bg-opacity-90 transition-colors"
              >
                Download Desktop App
              </a>
            </div>
          </div>

          {/* Mobile App */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="p-6">
              <h3 className="text-2xl font-bold text-pdf-gray mb-4">PDFAI Mobile</h3>
              <p className="text-pdf-gray mb-6">
                Get the <a href="/mobile" className="text-pdf-red font-medium">PDFAI Mobile</a> App to
                manage documents remotely or on the move. Turn your Android or iPhone
                device into a PDF Editor & Scanner to annotate, sign, and share documents with ease.
              </p>
              <div className="flex flex-wrap gap-4">
                <a
                  href="https://play.google.com/store/apps"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-block"
                >
                  <img
                    src="https://ext.same-assets.com/2319839531/2439909587.svg"
                    alt="Google Play"
                    className="h-10"
                  />
                </a>
                <a
                  href="https://apps.apple.com/app/apple-store"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-block"
                >
                  <img
                    src="https://ext.same-assets.com/2319839531/2364614318.svg"
                    alt="App Store"
                    className="h-10"
                  />
                </a>
              </div>
            </div>
          </div>

          {/* ImageAI */}
          <div className="bg-white rounded-lg shadow-md overflow-hidden">
            <div className="p-6">
              <h3 className="text-2xl font-bold text-pdf-gray mb-4">ImageAI</h3>
              <p className="text-pdf-gray mb-6">
                <a href="https://www.imageai.com" className="text-pdf-red font-medium">ImageAI</a> is the web app that helps you
                modify images in bulk for free. Crop, resize, compress, convert, and more. All the tools you need to enhance
                your images in just a few clicks.
              </p>
              <a
                href="https://www.imageai.com"
                className="inline-block bg-pdf-blue text-white font-medium px-4 py-2 rounded hover:bg-opacity-90 transition-colors"
                target="_blank"
                rel="noopener noreferrer"
              >
                Visit ImageAI
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default AppsSection;
