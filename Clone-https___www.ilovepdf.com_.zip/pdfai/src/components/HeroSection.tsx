import { Link } from 'react-router-dom';

const HeroSection = () => {
  return (
    <section className="bg-pdf-bg py-12 md:py-20">
      <div className="container mx-auto px-4 text-center">
        <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-pdf-gray mb-4">
          Every tool you need to work with PDFs in one place
        </h1>
        <p className="text-lg md:text-xl text-pdf-gray mb-12 max-w-4xl mx-auto">
          Every tool you need to use PDFs, at your fingertips. All are 100% FREE and easy to use!
          Merge, split, compress, convert, rotate, unlock and watermark PDFs with just a few clicks.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {/* Merge PDF */}
          <Link to="/merge-pdf" className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow block">
            <div className="w-12 h-12 bg-red-100 rounded-lg mb-4 flex items-center justify-center mx-auto">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2M10 20h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" stroke="#ca5a60" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
            <h3 className="text-xl font-semibold text-pdf-gray mb-2">Merge PDF</h3>
            <p className="text-pdf-gray text-sm">
              Combine PDFs in the order you want with the easiest PDF merger available.
            </p>
          </Link>

          {/* Split PDF */}
          <Link to="/split-pdf" className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow block">
            <div className="w-12 h-12 bg-red-100 rounded-lg mb-4 flex items-center justify-center mx-auto">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M8 3v3a2 2 0 01-2 2H3m18 0h-3a2 2 0 01-2-2V3M3 16h3a2 2 0 012 2v3m8-3v3a2 2 0 002 2h3" stroke="#ca5a60" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
            <h3 className="text-xl font-semibold text-pdf-gray mb-2">Split PDF</h3>
            <p className="text-pdf-gray text-sm">
              Separate one page or a whole set for easy conversion into independent PDF files.
            </p>
          </Link>

          {/* Compress PDF */}
          <Link to="/compress-pdf" className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow block">
            <div className="w-12 h-12 bg-green-100 rounded-lg mb-4 flex items-center justify-center mx-auto">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M7 10l5 5 5-5M12 15V3" stroke="#4CAF50" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
            <h3 className="text-xl font-semibold text-pdf-gray mb-2">Compress PDF</h3>
            <p className="text-pdf-gray text-sm">
              Reduce file size while optimizing for maximal PDF quality.
            </p>
          </Link>

          {/* PDF to Word */}
          <Link to="/pdf-to-word" className="bg-white rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow block">
            <div className="w-12 h-12 bg-blue-100 rounded-lg mb-4 flex items-center justify-center mx-auto">
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8l-6-6z" stroke="#5ab7d0" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                <path d="M14 2v6h6M16 13H8M16 17H8M10 9H8" stroke="#5ab7d0" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
            <h3 className="text-xl font-semibold text-pdf-gray mb-2">PDF to Word</h3>
            <p className="text-pdf-gray text-sm">
              Easily convert your PDF files into easy to edit DOC and DOCX documents.
            </p>
          </Link>
        </div>
      </div>
    </section>
  );
};

export default HeroSection;
