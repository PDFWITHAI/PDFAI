import { Link } from 'react-router-dom';

interface Tool {
  id: string;
  name: string;
  description: string;
  icon: React.ReactNode;
  isNew?: boolean;
  bgColor: string;
}

const ToolsGrid = () => {
  const tools: Tool[] = [
    {
      id: "pdf-to-powerpoint",
      name: "PDF to PowerPoint",
      description: "Turn your PDF files into easy to edit PPT and PPTX slideshows.",
      icon: (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-8 h-8">
          <rect width="24" height="24" rx="4" fill="#F5BFBF" />
          <path d="M7 18V6h10a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H7zm5-9h4v4h-4V9z" fill="#ca5a60" />
        </svg>
      ),
      bgColor: "bg-red-50"
    },
    {
      id: "pdf-to-excel",
      name: "PDF to Excel",
      description: "Pull data straight from PDFs into Excel spreadsheets in a few short seconds.",
      icon: (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-8 h-8">
          <rect width="24" height="24" rx="4" fill="#D7F5D7" />
          <path d="M7 5h10a2 2 0 0 1 2 2v10a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V7a2 2 0 0 1 2-2zm6 2v4h4v2h-4v4h-2v-4H7v-2h4V7h2z" fill="#4CAF50" />
        </svg>
      ),
      bgColor: "bg-green-50"
    },
    {
      id: "word-to-pdf",
      name: "Word to PDF",
      description: "Make DOC and DOCX files easy to read by converting them to PDF.",
      icon: (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-8 h-8">
          <rect width="24" height="24" rx="4" fill="#D0EEF7" />
          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6zm-1 2l5 5h-5V4zM8 14h8v2H8v-2zm0 4h8v2H8v-2zm0-8h3v2H8v-2z" fill="#5ab7d0" />
        </svg>
      ),
      bgColor: "bg-blue-50"
    },
    {
      id: "powerpoint-to-pdf",
      name: "PowerPoint to PDF",
      description: "Make PPT and PPTX slideshows easy to view by converting them to PDF.",
      icon: (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-8 h-8">
          <rect width="24" height="24" rx="4" fill="#F5BFBF" />
          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6zm-1 2l5 5h-5V4zm-2 10H8v-2h3a2 2 0 1 1 0 4h-1v3H8v-3h2v-2z" fill="#ca5a60" />
        </svg>
      ),
      bgColor: "bg-red-50"
    },
    {
      id: "excel-to-pdf",
      name: "Excel to PDF",
      description: "Make EXCEL spreadsheets easy to read by converting them to PDF.",
      icon: (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-8 h-8">
          <rect width="24" height="24" rx="4" fill="#D7F5D7" />
          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6zm-1 2l5 5h-5V4zm-5 12h3v-3h2v3h3v2h-3v3h-2v-3H8v-2z" fill="#4CAF50" />
        </svg>
      ),
      bgColor: "bg-green-50"
    },
    {
      id: "edit-pdf",
      name: "Edit PDF",
      description: "Add text, images, shapes or freehand annotations to a PDF document. Edit the size, font, and color of the added content.",
      icon: (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-8 h-8">
          <rect width="24" height="24" rx="4" fill="#F5D0F5" />
          <path d="M11 4H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2v-7M17.5 2.5a2.121 2.121 0 0 1 3 3L12 14l-4 1 1-4 8.5-8.5z" fill="#9C27B0" stroke="#9C27B0" strokeWidth="1.5" />
        </svg>
      ),
      isNew: true,
      bgColor: "bg-purple-50"
    },
    {
      id: "pdf-to-jpg",
      name: "PDF to JPG",
      description: "Convert each PDF page into a JPG or extract all images contained in a PDF.",
      icon: (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-8 h-8">
          <rect width="24" height="24" rx="4" fill="#FEF5D0" />
          <path d="M15 10.5a3 3 0 1 1-6 0 3 3 0 0 1 6 0z" fill="#d6b448" />
          <path d="M19 2H5a3 3 0 0 0-3 3v14a3 3 0 0 0 3 3h14a3 3 0 0 0 3-3V5a3 3 0 0 0-3-3zm-9 15a5 5 0 1 1 0-10 5 5 0 0 1 0 10z" fill="#d6b448" />
        </svg>
      ),
      bgColor: "bg-yellow-50"
    },
    {
      id: "jpg-to-pdf",
      name: "JPG to PDF",
      description: "Convert JPG images to PDF in seconds. Easily adjust orientation and margins.",
      icon: (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-8 h-8">
          <rect width="24" height="24" rx="4" fill="#FEF5D0" />
          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6zm-1 2l5 5h-5V4zm-1 8a3 3 0 1 1-6 0 3 3 0 0 1 6 0z" fill="#d6b448" />
        </svg>
      ),
      bgColor: "bg-yellow-50"
    },
    {
      id: "sign-pdf",
      name: "Sign PDF",
      description: "Sign yourself or request electronic signatures from others.",
      icon: (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-8 h-8">
          <rect width="24" height="24" rx="4" fill="#F5D0F5" />
          <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4m6 18v-3H9v3m6-6v-3H9v3m6-6V3H9v3h6z" fill="#9C27B0" />
        </svg>
      ),
      bgColor: "bg-purple-50"
    },
    {
      id: "watermark",
      name: "Watermark",
      description: "Stamp an image or text over your PDF in seconds. Choose the typography, transparency and position.",
      icon: (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-8 h-8">
          <rect width="24" height="24" rx="4" fill="#F5D0F5" />
          <path d="M20 5H4v14l.01.01H20V5zm-2 12H6v-5h2v3h2v-6h2v6h2v-2h4v4z" fill="#9C27B0" />
        </svg>
      ),
      bgColor: "bg-purple-50"
    },
    {
      id: "rotate-pdf",
      name: "Rotate PDF",
      description: "Rotate your PDFs the way you need them. You can even rotate multiple PDFs at once!",
      icon: (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-8 h-8">
          <rect width="24" height="24" rx="4" fill="#F5D0F5" />
          <path d="M17.65 6.35A7.958 7.958 0 0 0 12 4c-4.42 0-7.99 3.58-7.99 8s3.57 8 7.99 8c3.73 0 6.84-2.55 7.73-6h-2.08A5.99 5.99 0 0 1 12 18c-3.31 0-6-2.69-6-6s2.69-6 6-6c1.66 0 3.14.69 4.22 1.78L13 11h7V4l-2.35 2.35z" fill="#9C27B0" />
        </svg>
      ),
      bgColor: "bg-purple-50"
    },
    {
      id: "html-to-pdf",
      name: "HTML to PDF",
      description: "Convert webpages in HTML to PDF. Copy and paste the URL of the page you want and convert it to PDF with a click.",
      icon: (
        <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-8 h-8">
          <rect width="24" height="24" rx="4" fill="#FEF5D0" />
          <path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8l-6-6zm-1 2l5 5h-5V4zM9 17l-2-2 2-2 1 1-1 1 1 1-1 1zm5-6v2h-3v-2h3zm2 6.5l-1-1 1-1-1-1 1-1 2 2-2 2z" fill="#d6b448" />
        </svg>
      ),
      bgColor: "bg-yellow-50"
    },
  ];

  return (
    <section className="bg-pdf-bg py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
          {tools.map((tool) => (
            <Link
              key={tool.id}
              to={`/${tool.id}`}
              className={`block ${tool.bgColor} rounded-lg shadow-md p-6 hover:shadow-lg transition-shadow relative`}
            >
              <div className="flex items-start">
                <div className="mr-4">{tool.icon}</div>
                <div>
                  <h3 className="text-xl font-semibold text-pdf-gray mb-2">{tool.name}</h3>
                  <p className="text-pdf-gray text-sm">
                    {tool.description}
                  </p>
                </div>
              </div>
              {tool.isNew && (
                <span className="absolute top-4 right-4 bg-pdf-red text-white text-xs font-bold px-2 py-1 rounded">
                  New!
                </span>
              )}
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ToolsGrid;
