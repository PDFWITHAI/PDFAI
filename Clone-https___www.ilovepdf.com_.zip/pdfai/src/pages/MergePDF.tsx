import { useState } from 'react';

const MergePDF = () => {
  const [files, setFiles] = useState<File[]>([]);
  const [dragging, setDragging] = useState(false);

  const handleDragOver = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setDragging(true);
  };

  const handleDragLeave = () => {
    setDragging(false);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    setDragging(false);

    if (e.dataTransfer.files) {
      const newFiles = Array.from(e.dataTransfer.files).filter(
        file => file.type === 'application/pdf'
      );

      if (newFiles.length > 0) {
        setFiles(prevFiles => [...prevFiles, ...newFiles]);
      }
    }
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const newFiles = Array.from(e.target.files).filter(
        file => file.type === 'application/pdf'
      );

      if (newFiles.length > 0) {
        setFiles(prevFiles => [...prevFiles, ...newFiles]);
      }
    }
  };

  const removeFile = (index: number) => {
    setFiles(prevFiles => prevFiles.filter((_, i) => i !== index));
  };

  const moveFileUp = (index: number) => {
    if (index === 0) return;
    const newFiles = [...files];
    const temp = newFiles[index];
    newFiles[index] = newFiles[index - 1];
    newFiles[index - 1] = temp;
    setFiles(newFiles);
  };

  const moveFileDown = (index: number) => {
    if (index === files.length - 1) return;
    const newFiles = [...files];
    const temp = newFiles[index];
    newFiles[index] = newFiles[index + 1];
    newFiles[index + 1] = temp;
    setFiles(newFiles);
  };

  return (
    <div className="bg-pdf-bg">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-3xl font-bold text-pdf-gray text-center mb-4">Merge PDF Files</h1>
        <p className="text-center text-pdf-gray mb-8 max-w-2xl mx-auto">
          Combine multiple PDFs into one document. Arrange them in the order you want and join them with a click.
        </p>

        <div className="max-w-3xl mx-auto">
          {/* File Drop Zone */}
          <div
            className={`border-2 border-dashed rounded-lg p-8 mb-6 text-center cursor-pointer ${
              dragging ? 'border-pdf-red bg-red-50' : 'border-gray-300 hover:border-pdf-red'
            }`}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            onClick={() => document.getElementById('file-input')?.click()}
          >
            <div className="flex flex-col items-center">
              <svg className="w-16 h-16 text-pdf-red mb-4" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12"></path>
              </svg>
              <h3 className="text-lg font-semibold text-pdf-gray mb-2">
                Drop PDF files here
              </h3>
              <p className="text-pdf-gray mb-4">
                or click to browse from your computer
              </p>
              <input
                id="file-input"
                type="file"
                accept=".pdf"
                multiple
                className="hidden"
                onChange={handleFileInputChange}
              />
              <button className="bg-pdf-red text-white px-4 py-2 rounded font-medium hover:bg-opacity-90 transition-colors">
                Select PDF Files
              </button>
            </div>
          </div>

          {/* File List */}
          {files.length > 0 && (
            <div className="bg-white rounded-lg shadow-md p-6 mb-6">
              <h3 className="text-lg font-semibold text-pdf-gray mb-4">
                {files.length} {files.length === 1 ? 'File' : 'Files'} Selected
              </h3>

              <ul className="space-y-3">
                {files.map((file, index) => (
                  <li
                    key={`${file.name}-${index}`}
                    className="flex items-center justify-between bg-gray-50 p-3 rounded"
                  >
                    <div className="flex items-center">
                      <svg className="w-8 h-8 text-pdf-red mr-3" viewBox="0 0 24 24" fill="currentColor" xmlns="http://www.w3.org/2000/svg">
                        <path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8l-6-6z" />
                        <path d="M14 8V2l6 6h-6z" fill="white" />
                        <path d="M11.5 13.5h-2v-1h2v1zm0 2h-2v-1h2v1zm0 2h-2v-1h2v1zm5-4h-3v-1h3v1zm0 2h-3v-1h3v1zm0 2h-3v-1h3v1z" fill="white" />
                      </svg>
                      <div className="overflow-hidden">
                        <p className="text-pdf-gray font-medium truncate" title={file.name}>
                          {file.name}
                        </p>
                        <p className="text-xs text-gray-500">
                          {(file.size / 1024).toFixed(1)} KB
                        </p>
                      </div>
                    </div>
                    <div className="flex space-x-2">
                      <button
                        onClick={() => moveFileUp(index)}
                        disabled={index === 0}
                        className={`p-1 rounded ${index === 0 ? 'text-gray-300 cursor-not-allowed' : 'text-pdf-gray hover:bg-gray-200'}`}
                        title="Move up"
                      >
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 15l7-7 7 7" />
                        </svg>
                      </button>
                      <button
                        onClick={() => moveFileDown(index)}
                        disabled={index === files.length - 1}
                        className={`p-1 rounded ${index === files.length - 1 ? 'text-gray-300 cursor-not-allowed' : 'text-pdf-gray hover:bg-gray-200'}`}
                        title="Move down"
                      >
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 9l-7 7-7-7" />
                        </svg>
                      </button>
                      <button
                        onClick={() => removeFile(index)}
                        className="p-1 rounded text-pdf-gray hover:bg-gray-200"
                        title="Remove"
                      >
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" />
                        </svg>
                      </button>
                    </div>
                  </li>
                ))}
              </ul>

              <div className="mt-6">
                <button className="w-full bg-pdf-red text-white py-3 rounded-lg font-medium hover:bg-opacity-90 transition-colors">
                  Merge PDF Files
                </button>
              </div>
            </div>
          )}

          {/* How It Works */}
          <div className="bg-white rounded-lg shadow-md p-6">
            <h3 className="text-xl font-semibold text-pdf-gray mb-4">
              How to Merge PDF Files
            </h3>

            <ol className="space-y-4">
              <li className="flex">
                <div className="flex-shrink-0 flex items-center justify-center h-8 w-8 rounded-full bg-pdf-red text-white font-bold mr-3">
                  1
                </div>
                <div>
                  <h4 className="font-medium text-pdf-gray">Upload your PDF files</h4>
                  <p className="text-gray-600 text-sm">Click the upload button or drag and drop your PDF files.</p>
                </div>
              </li>
              <li className="flex">
                <div className="flex-shrink-0 flex items-center justify-center h-8 w-8 rounded-full bg-pdf-red text-white font-bold mr-3">
                  2
                </div>
                <div>
                  <h4 className="font-medium text-pdf-gray">Arrange the files in the order you want</h4>
                  <p className="text-gray-600 text-sm">Use the up and down arrows to change the order if needed.</p>
                </div>
              </li>
              <li className="flex">
                <div className="flex-shrink-0 flex items-center justify-center h-8 w-8 rounded-full bg-pdf-red text-white font-bold mr-3">
                  3
                </div>
                <div>
                  <h4 className="font-medium text-pdf-gray">Click "Merge PDF Files"</h4>
                  <p className="text-gray-600 text-sm">Once you've arranged your files, click the merge button to combine them into one PDF.</p>
                </div>
              </li>
              <li className="flex">
                <div className="flex-shrink-0 flex items-center justify-center h-8 w-8 rounded-full bg-pdf-red text-white font-bold mr-3">
                  4
                </div>
                <div>
                  <h4 className="font-medium text-pdf-gray">Download your merged PDF</h4>
                  <p className="text-gray-600 text-sm">Once the merging is complete, download your new PDF file.</p>
                </div>
              </li>
            </ol>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MergePDF;
